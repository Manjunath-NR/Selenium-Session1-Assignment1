package com.ibm.seleniumconcepts;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SeleniumBrowser {

	public static void main(String[] args) {
		
	 
	//WebDriver driver =new FirefoxDriver();
	
	 //WebDriver driver =new ChromeDriver();
	
	 WebDriver driver =new InternetExplorerDriver();
	}

}
